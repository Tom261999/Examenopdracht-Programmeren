/*
	Inleiding Programmeren: Examenopdracht
	Tom Stoops (s0173659)
	Tom.Stoops@student.uantwerpen.be
	Ingeleverd op: 19-05-2019
 */

#pragma once

// Extra source & header files om orde te houden in de main(), we zullen iedere opdracht appart uitvoeren met behulp van een void functie waarin alles wat nodig is om de opdrachten uit te voeren aangeroepen wordt
// We geven zo ook in de functies (die hieronder declared zijn) extra structuur in de output voor onze opgaven

void Opdracht_1();
void Opdracht_2();
void Opdracht_3();
void Opdracht_4();
void Opdracht_5();
void Opdracht_6();