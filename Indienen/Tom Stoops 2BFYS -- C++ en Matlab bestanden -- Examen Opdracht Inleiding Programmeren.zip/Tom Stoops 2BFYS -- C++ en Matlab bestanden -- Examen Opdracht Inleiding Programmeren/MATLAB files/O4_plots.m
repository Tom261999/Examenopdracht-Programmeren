clear, close all;

% importeer data
vx = importdata('O4_vectors_x.txt','\t');
vy = importdata('O4_vectors_y.txt','\t');
S = importdata('O4_stream.txt','\t');
P = importdata('O4_potential.txt','\t');

% initialiseer grid
minX = -2; maxX = 2;
minY = -1; maxY = 1;
[nY,nX] = size(S);
[X,Y] = meshgrid(linspace(minX,maxX,nX),linspace(minY,maxY,nY));

% plot: snelheidsvectoren & stroomlijnen
figure(1), hold on, box on;
streamslice(X,Y,vx,vy,5)

set(gca,'FontSize',11)
xlabel('x-as')
ylabel('y-as')
title({'Doublet in Uniforme Stroom:','Stroomlijnen \psi & Snelheidsvectoren'})
daspect([1 1 1])

% plot cp ifv theta
figure(2);
f = @(t) (1-4*(sin(t)).^2);
fplot(f,[0,2*pi],'k','LineWidth',1.5);
grid on;
set(gca,'XTick',0:pi/2:2*pi);
set(gca,'FontSize',11)
set(gca,'XTickLabel',{'0','\pi/2','\pi','3*\pi/2','2*\pi'});
title({'Doublet in Uniforme Stroom:','Drukco�ffici�nt i.f.v. de Hoek'})
xlabel('\theta')
ylabel('Drukco�ffic�nt C_p')
legend('C_p(r=a,\theta) = 1-4sin^2(\theta)')
daspect([1 1 1])